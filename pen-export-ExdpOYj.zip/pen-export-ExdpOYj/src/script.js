function calcularIMC() {
  const peso = parseFloat(document.getElementById("peso").value);
  const altura = parseFloat(document.getElementById("altura").value);

  const imc = peso / (altura * altura);
  document.getElementById("imc").innerHTML = imc.toFixed(2);

  let situacao;

  if (imc < 18.5) {
    situacao = "Abaixo do peso";
    document.getElementById("situacao").classList.add("alerta");
  } else if (imc >= 18.5 && imc < 25) {
    situacao = "Peso normal";
    document.getElementById("situacao").classList.add("normal");
  } else if (imc >= 25 && imc < 30) {
    situacao = "Acima do peso";
    document.getElementById("situacao").classList.add("alerta");
  } else if (imc >= 30 && imc < 35) {
    situacao = "Obesidade I";
    document.getElementById("situacao").classList.add("perigo");
  } else if (imc >= 35 && imc < 40) {
    situacao = "Obesidade II";
    document.getElementById("situacao").classList.add("perigo");
  } else {
    situacao = "Obesidade III";
    document.getElementById("situacao").classList.add("perigo");
  }

  document.getElementById("situacao").innerHTML = situacao;
}