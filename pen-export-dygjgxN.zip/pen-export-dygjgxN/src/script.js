function calcularMedia() {
  const nota1 = parseFloat(document.getElementById("nota1").value);
  const nota2 = parseFloat(document.getElementById("nota2").value);

  const media = (nota1 + nota2) / 2;

  let situacao, cor;

  if (media >= 6) {
    situacao = "Aprovado";
    cor = "aprovado";
  } else {
    situacao = "Reprovado";
    cor = "reprovado";
  }

  document.getElementById("media").innerHTML = media.toFixed(1);
  document.getElementById("situacao").innerHTML = situacao;
  document.getElementById("situacao").classList.add(cor);
}