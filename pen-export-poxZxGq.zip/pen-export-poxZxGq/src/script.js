
document.getElementById("appendButton").addEventListener("click", function() {
  // Get the input value
  const itemText = document.getElementById("itemText").value;

  // Create an "li" node:
  const node = document.createElement("li");

  // Set the text content of the node to the input value:
  node.textContent = itemText;

  // Get the selected color
  const colorRadios = document.getElementsByName("color");
  let selectedColor = "";
  for (let i = 0; i < colorRadios.length; i++) {
    if (colorRadios[i].checked) {
      selectedColor = colorRadios[i].value;
      break;
    }
  }

  // Set the color of the node
  node.style.color = selectedColor;

  // Append the "li" node to the list:
  document.getElementById("myList").appendChild(node);
});
